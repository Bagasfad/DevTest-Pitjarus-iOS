//
//  AuthUser.swift
//  DevTest
//
//  Created by Bagas Fadilla on 20/02/23.
//

import SwiftUI
import Foundation

class AuthUser: ObservableObject{

    // MARK: - Check Login
    @Published var isCorrect: Bool = true
    
    // MARK: Rubah state
    @Published var isLoggedin : Bool = false
   
}
