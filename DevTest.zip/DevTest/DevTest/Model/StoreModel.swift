//
//  StoreModel.swift
//  DevTest
//
//  Created by Bagas Fadilla on 21/02/23.
//

import Foundation

struct Shops: Codable {
    var stores: [StoreModel]?
    var status: String
    var message: String
        
    }

struct StoreModel: Codable,Identifiable{
    let id: String
    let storeName: String
    let address: String
    let areaID: String
    let areaName: String
    let regionID: String
    let regionName: String
    let latitude: String
    let longitude: String
    
    enum CodingKeys: String, CodingKey{
        case id = "store_id"
        case storeName = "store_name"
        case address
        case areaID = "area_id"
        case areaName = "area_name"
        case regionID = "region_id"
        case regionName = "region_name"
        case latitude, longitude
    }
}
