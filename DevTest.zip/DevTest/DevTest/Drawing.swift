//
//  Drawing.swift
//  DevTest
//
//  Created by Bagas Fadilla on 20/02/23.
//

import SwiftUI

struct Drawing: View {
    var body: some View {
        Path { path in
                   //Top left
                   path.move(to: CGPoint(x: 0, y: 0))
                   //Left vertical bound
                   path.addLine(to: CGPoint(x: 0, y: 220))
                   //Curve
                   path.addCurve(to: CGPoint(x: 400, y: 0), control1: CGPoint(x: 40, y: 20), control2: CGPoint(x: 350, y: 220))
                   //Right vertical bound
                   path.addLine(to: CGPoint(x: 450, y: 0))
               }
               .fill(.blue)
               .edgesIgnoringSafeArea(.top)
        
           }
       }

struct Drawing_Previews: PreviewProvider {
    static var previews: some View {
        Drawing()
    }
}
