//
//  API Call.swift
//  DevTest
//
//  Created by Bagas Fadilla on 21/02/23.
//

import Foundation

class APICall{
    func LoginCheck(username:String, password:String,completion:@escaping([StoreModel]) -> Void){
        
        guard let url = URL(string: "http://dev.pitjarus.co/api/sariroti_md/index.php/login/loginTest") else {
            return
        }
        
        let login = "username=\(username)&password=\(password)"
        let body =  login.data(using: .utf8)
        
        var request = URLRequest(url: url)
        
        request.setValue("application/form-data", forHTTPHeaderField: "Content-Type")
        request.httpMethod = "POST"
        request.httpBody = body
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            if error != nil {
                print("Data Error")
            }
            
            guard let data = data else { return }
            
            do {
                let decodedData = try? JSONDecoder().decode(Shops.self, from: data)
                DispatchQueue.main.async {
                    if let decoded = decodedData {
                        completion(decoded.stores ?? [])
                    }
                }
            } catch {
                print("Data Error\(error)")
            }
        }
        .resume()
        
    }
}

