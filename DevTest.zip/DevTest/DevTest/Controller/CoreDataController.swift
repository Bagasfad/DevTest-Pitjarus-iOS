//
//  CoreDataController.swift
//  DevTest
//
//  Created by Bagas Fadilla on 22/02/23.
//

import Foundation
import CoreData

class CoreDataManager {
    
    func fetchStoreDataFromCoreData(context: NSManagedObjectContext) -> [LocalData] {
        let request = NSFetchRequest<LocalData>(entityName: "LocalData")
        
        do {
            let storeData = try context.fetch(request)
            return storeData
        } catch {
            print("Data is Missing\(error)")
            return []
        }
    }
    
    func addNewDataToLocal(context: NSManagedObjectContext, store: StoreModel) {
        let newShop = LocalData(context: context)
        newShop.id = store.id
        newShop.shopName = store.storeName
        newShop.address = store.address
        newShop.areaID = store.areaID
        newShop.areaName = store.areaName
        newShop.regionID = store.regionID
        newShop.regionName = store.regionName
        newShop.latitude = store.latitude
        newShop.longitude = store.longitude
        newShop.isVisited = false
        
        saveContext(context: context)
    }
    
    func saveContext(context: NSManagedObjectContext) {
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                let nserror = error as NSError
                fatalError("Saving Error \(nserror), \(nserror.userInfo)")
            }
        }
    }
    
    func deleteAll(context: NSManagedObjectContext) {
        let fetchRequest: NSFetchRequest<NSFetchRequestResult> = LocalData.fetchRequest()
          let batchDeleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)
          _ = try? context.execute(batchDeleteRequest)
    }
    
    func updateDataInLocal(context: NSManagedObjectContext, currentStore: LocalData) {
        let current = currentStore
        current.isVisited = true
        
        do {
            try context.save()
        } catch {
            print("Update Data Error\(error)")
        }
    }
    
}
