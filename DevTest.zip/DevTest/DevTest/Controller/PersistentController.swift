//
//  PersistentController.swift
//  DevTest
//
//  Created by Bagas Fadilla on 22/02/23.
//

import Foundation
import CoreData

class PersistentController {
    // MARK: - 1. Persistence Controller
    static let shared = PersistentController()
    
    lazy var persistentContainer: NSPersistentContainer = {
        
        // MARK: - 2. Persistence Container
        let container = NSPersistentContainer(name: "StoreSQLite")
        
        // MARK: - 3. initialization (load the persistent store)
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                fatalError("Container Error \(error), \(error.userInfo)")
            }
        })
        return container
    }()
}
