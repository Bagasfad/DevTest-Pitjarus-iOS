//
//  LoginView.swift
//  DevTest
//
//  Created by Bagas Fadilla on 20/02/23.
//

import SwiftUI

struct LoginView: View {
    // MARK: - Properties
    @EnvironmentObject var userAuth : AuthUser
    @State var username : String = ""
    @State var password : String = ""
    
    let lightGreyColor = Color(red:239/255, green: 243/255, blue: 244/255,opacity: 1)
    
    // MARK: - Login Check
    func LoginCheck(){
        if(username == "pitjarus" && password == "admin"){
            userAuth.isLoggedin = true
        }else{
            userAuth.isLoggedin = false
            userAuth.isCorrect = false
        }
    }
    
    // MARK: - Body
    var body: some View {
        ZStack {
            Color.white
                .edgesIgnoringSafeArea(.all)
            
            VStack{
                HStack {
                    Drawing()
                }//: Hstack
                   .frame(height: 150)
                
                // MARK: - Form Field
                VStack(alignment: .leading){
                    //Username
                    HStack{
                        Image(systemName: "person.circle")
                        TextField("Username...", text: $username)
                            .padding()
                            .background(lightGreyColor)
                            .cornerRadius(5)
                            .keyboardType(.emailAddress)
                            .autocapitalization(.none)
                    }//: Hstack
                    //Password
                    HStack{
                        Image(systemName: "lock.fill")
                        SecureField("Password...", text: $password)
                            .padding()
                            .background(lightGreyColor)
                            .cornerRadius(5)
                            .autocapitalization(.none)
                    }//: Hstack
                    // MARK: - Tampilan Kesalahan Password
                    if(!userAuth.isCorrect){
                        Text("Username dan password salah")
                            .foregroundColor(.red)
                    }
                    
                    // MARK: - Forgot Password
                    HStack{
                        CheckView(title: "Keep Username")
                       
                    }//: Hstack

                    
                    // MARK: - Sign in Button
                    HStack{
                        Spacer()
                        Button(action:{self.LoginCheck()}){
                            Text("Sign in").bold()
                                .font(.callout)
                                .foregroundColor(.white)
                        }
                        Spacer()
                    }//: Hstack
                    .padding()
                    .background(Color.blue)
                    .cornerRadius(15)
                    
                    // MARK: - App version
                    HStack{
                        Spacer()
                            Text("App Version 1.0").bold()
                                .font(.callout)
                                .foregroundColor(.blue)
                        
                        Spacer()
                    }//: Hstack
                    .padding()
                }.padding(30)
                Spacer()
            } //: Vstack
        }
    }
}


struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView().environmentObject(AuthUser())
    }
}
