//
//  Home.swift
//  DevTest
//
//  Created by Bagas Fadilla on 21/02/23.
//

import SwiftUI

struct Home: View {
    // MARK: - Properties
    @EnvironmentObject var userAuth : AuthUser
    
    // MARK: - Body
    var body: some View {
        NavigationView{
            ZStack{
                //MapView()
                //.frame(height: 300)
                Text("Store List")
                    .navigationBarTitle("List Store",displayMode:.inline)
                    .navigationBarItems(trailing:
                                            Button(action: {self.userAuth.isLoggedin = false}){
                        Text("Logout")
                    }
                
                )
            }//: Zstack
            }
        }
    }

struct Home_Previews: PreviewProvider {
    static var previews: some View {
        Home()
    }
}
