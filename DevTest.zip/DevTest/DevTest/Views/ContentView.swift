//
//  ContentView.swift
//  DevTest
//
//  Created by Bagas Fadilla on 20/02/23.
//

import SwiftUI

struct ContentView: View {
    // MARK: - Properties
    @EnvironmentObject var userAuth : AuthUser
    
    // MARK: - Body
    var body: some View {
        if !userAuth.isLoggedin {
        return AnyView(LoginView())
        } else {
        return AnyView(Home())
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView().environmentObject(AuthUser())
    }
}
