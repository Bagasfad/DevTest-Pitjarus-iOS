//
//  Drawing2.swift
//  DevTest
//
//  Created by Bagas Fadilla on 21/02/23.
//

import SwiftUI

struct Drawing2: View {
    var body: some View {
        
        
       Path { path in
                   //Bottom left
                   path.move(to: CGPoint(x: 0, y: 900))
                   //Left vertical bound
                   path.addLine(to: CGPoint(x: 0, y: 510))
                   //Curve
                   path.addCurve(to: CGPoint(x: 450, y: 800), control1: CGPoint(x: 10, y: 800), control2: CGPoint(x: 250, y: 520))
                   //Right vertical bound
                   path.addLine(to: CGPoint(x: 950, y: 770))
               }
        .fill(.blue)
        .edgesIgnoringSafeArea(.bottom)
    }
    
}

struct Drawing2_Previews: PreviewProvider {
    static var previews: some View {
        Drawing2()
    }
}
